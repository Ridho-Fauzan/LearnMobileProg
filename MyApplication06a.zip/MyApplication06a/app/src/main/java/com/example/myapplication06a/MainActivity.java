package com.example.myapplication06a;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id==R.id.menu_help){
            Toast.makeText(this, "help di klik", Toast.LENGTH_SHORT).show();
            return true;
        }else if(id==R.id.menu_settings){
            Toast.makeText(this, "settings di klik", Toast.LENGTH_SHORT).show();
            Intent niatSettings = new Intent(this, SettingsActivity.class);
            startActivity(niatSettings);
            return true;
        }else if(id==R.id.menu_logout){
            Toast.makeText(this, "logout di klik", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}