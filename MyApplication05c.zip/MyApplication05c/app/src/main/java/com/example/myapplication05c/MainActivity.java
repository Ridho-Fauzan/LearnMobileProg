package com.example.myapplication05c;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Song> songs;
    RecyclerView rvSongs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        songs = new ArrayList<>();
        for(int i=0;i<100;i++){
            String title = "Judul "+i;
            String artist = "Artis "+i;
            Song tempSong = new Song(title,artist);
            songs.add(tempSong);
        }

        rvSongs = findViewById(R.id.rvSongs);
        rvSongs.setLayoutManager(new LinearLayoutManager(this));
        SongAdapter songAdapter = new SongAdapter(songs,clickedSong -> {
            Toast.makeText(this,
                    clickedSong.getTitle()+" is clicked",
                    Toast.LENGTH_LONG).show();
        });
        rvSongs.setAdapter(songAdapter);

    }
}