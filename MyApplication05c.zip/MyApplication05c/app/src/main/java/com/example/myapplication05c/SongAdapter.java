package com.example.myapplication05c;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SongAdapter extends RecyclerView.Adapter<SongAdapter.SongViewHolder>{

    ArrayList<Song> songsInAdapter;
    OnItemClickListener listener;
    public interface  OnItemClickListener{
        void onItemClick(Song song);
    }

    public SongAdapter(ArrayList<Song> songs, OnItemClickListener listener) {
        songsInAdapter = songs;
        this.listener = listener;
    }

    @NonNull
    @Override
    public SongViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_song,parent,false);
        return new SongViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SongViewHolder holder, int position) {
        Song song = songsInAdapter.get(position);
        holder.tvSongTitle.setText(song.getTitle());
        holder.tvSongArtist.setText(song.getArtist());

        holder.itemView.setOnClickListener(v->{
            if(listener!=null){
                listener.onItemClick(song);
            }
        });
    }

    @Override
    public int getItemCount() {
        return songsInAdapter.size();
    }

    public class SongViewHolder extends RecyclerView.ViewHolder{
        TextView tvSongTitle,tvSongArtist;
        public SongViewHolder(@NonNull View itemView) {
            super(itemView);
            tvSongTitle = itemView.findViewById(R.id.tvSongTitle);
            tvSongArtist = itemView.findViewById(R.id.tvSongArtist);
        }
    }
}
