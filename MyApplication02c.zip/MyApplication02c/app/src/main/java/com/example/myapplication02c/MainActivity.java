package com.example.myapplication02c;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnLogin,btnRegister;
    EditText etUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);
        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        etUsername = findViewById(R.id.etUsername);

    }

    @Override
    public void onClick(View view) {
        if(view.getId()==R.id.btnLogin){
            Toast.makeText(this, "Login ditekan", Toast.LENGTH_SHORT).show();
            String strUsername = etUsername.getText().toString();

            Intent niatPindahHalaman = new Intent(this, MainActivity2.class);
            niatPindahHalaman.putExtra("keyUsername",strUsername);
            startActivity(niatPindahHalaman);

        }else if(view.getId()==R.id.btnRegister){
            String strUri = "https://www.instagram.com";
            Uri uri = Uri.parse(strUri);
            Intent niatBrowser = new Intent(Intent.ACTION_VIEW,uri);
            startActivity(niatBrowser);
        }
    }

}